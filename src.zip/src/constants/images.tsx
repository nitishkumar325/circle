export default {
  AppLogo: require('../assets/Images/AppLogo.png'),
  loginBack: require('../assets/Images/loginBack.png'),
  eyeClosed: require('../assets/Images/eyeClosed.png'),
  eyeOpen: require('../assets/Images/EyeIcon.png'),
  lock: require('../assets/Images/lock.png'),
  User: require('../assets/Images/User.png'),
  mobile_icon: require('../assets/Images/mobile_icon.png'),
  arrowLeftBlack: require('../assets/Images/arrow-left(non-optimized).png'),
};
